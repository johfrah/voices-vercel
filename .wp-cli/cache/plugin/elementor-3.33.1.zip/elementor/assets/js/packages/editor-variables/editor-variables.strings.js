__( 'Unexpected response from server', 'elementor' );
__( 'Unexpected response from server', 'elementor' );
__( 'Give your variable a name.', 'elementor' );
__( 'Add a value to complete your variable.', 'elementor' );
__( 'Use letters, numbers, dashes (-), or underscores (_) for the name.', 'elementor' );
__( 'Names have to include at least one non-special character.', 'elementor' );
__( 'Keep names up to 50 characters.', 'elementor' );
__( 'This variable name already exists. Please choose a unique name.', 'elementor' );
__( 'There was a glitch. Try saving your variable again.', 'elementor' );
__( 'We found %1$d duplicated %2$s.', 'elementor' );
__( 'There was a glitch.', 'elementor' );
__( 'Take me there', 'elementor' );
__( 'Please rename the variables.', 'elementor' );
__( 'Try saving your variables again.', 'elementor' );
__( 'Missing variable', 'elementor' );
__( 'Variables', 'elementor' );
__( 'Create variable', 'elementor' );
__( 'Variables Manager', 'elementor' );
/* translators: %s: Variable Type. */
__( 'Create your first %s variable', 'elementor' );
__( 'Variables', 'elementor' );
__( 'Search', 'elementor' );
__(
						'Variables are saved attributes that you can apply anywhere on your site.',
						'elementor'
					);
__( 'No compatible variables', 'elementor' );
__(
						'Looks like none of your variables work with this control. Create a new variable to use it here.',
						'elementor'
					);
__( 'Restore variable', 'elementor' );
__( 'Name', 'elementor' );
__( 'Value', 'elementor' );
__( 'Restore', 'elementor' );
__( 'Delete variable', 'elementor' );
__( 'Edit variable', 'elementor' );
__( 'Go Back', 'elementor' );
__( 'Name', 'elementor' );
__( 'Value', 'elementor' );
__( 'Save', 'elementor' );
__( 'Go Back', 'elementor' );
__( 'Create variable', 'elementor' );
__( 'Name', 'elementor' );
__( 'Value', 'elementor' );
__( 'Create', 'elementor' );
__( 'Name', 'elementor' );
__( 'Value', 'elementor' );
__( 'Delete', 'elementor' );
__( 'Variables Manager', 'elementor' );
__( 'Search', 'elementor' );
__( 'Create your first variable', 'elementor' );
__(
								'Variables are saved attributes that you can apply anywhere on your site.',
								'elementor'
							);
__( 'Save changes', 'elementor' );
__( 'You have unsaved changes', 'elementor' );
__( 'To avoid losing your updates, save your changes before leaving.', 'elementor' );
__( 'Discard', 'elementor' );
__( 'Save', 'elementor' );
__( 'Add variable', 'elementor' );
__( 'Sorry, nothing matched', 'elementor' );
__( 'Try something else.', 'elementor' );
__( 'Clear & try again', 'elementor' );
__( 'Clear', 'elementor' );
__( 'This variable is missing', 'elementor' );
__(
						'It may have been deleted. Try clearing this field and select a different value or variable.',
						'elementor'
					);
__( 'Variable has changed', 'elementor' );
__(
		`This variable is no longer compatible with this property. You can clear it or select a different one.`,
		'elementor'
	);
__( 'Clear', 'elementor' );
__( 'Select variable', 'elementor' );
__( 'Edit variable', 'elementor' );
__( 'Create a variable', 'elementor' );
__( 'There are no variables', 'elementor' );
__( 'With your current role, you can only connect and detach variables.', 'elementor' );
__( 'Changes to variables go live right away.', 'elementor' );
__(
						"Don't worry - all other changes you make will wait until you publish your site.",
						'elementor'
					);
__( "Don't show me again", 'elementor' );
__( 'Keep editing', 'elementor' );
__( 'Save', 'elementor' );
__( 'Unlink', 'elementor' );
__( 'Restore', 'elementor' );
__( 'Deleted variable', 'elementor' );
__( 'The variable', 'elementor' );
__(
						'has been deleted, but it is still referenced in this location. You may restore the variable or unlink it to assign a different value.',
						'elementor'
					);
__( 'Delete this variable?', 'elementor' );
__( 'All elements using', 'elementor' );
__( 'will keep their current values, but the variable itself will be removed.', 'elementor' );
__( 'Not now', 'elementor' );
__( 'Delete', 'elementor' );
__( 'Font family', 'elementor' );
__( 'Missing variable', 'elementor' );
__( 'changed', 'elementor' );
__( 'deleted', 'elementor' );
__( 'Unlink variable', 'elementor' );